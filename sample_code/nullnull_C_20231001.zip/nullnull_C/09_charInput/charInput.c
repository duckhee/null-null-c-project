#include <stdio.h>

int main(void)
{
    char ch = 0;

    ch = getchar();
    putchar(ch);
    putchar('Z');

	return 0;
}

