#include <stdio.h>

int main(void)
{
	int nResult;
	nResult += 10;
	nResult += 10;
	nResult += 10;
	return 0;
}