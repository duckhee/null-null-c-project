#include <stdio.h>

int main(void)
{
	int nInput = 0;
	scanf_s("%d\n", &nInput);

	printf("%d\n", nInput);
	return 0;
}
