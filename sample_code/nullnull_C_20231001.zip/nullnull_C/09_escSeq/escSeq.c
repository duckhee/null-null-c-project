#include <stdio.h>

int main(void)
{
    int x = 10;

    putchar('B');
    putchar('\n');
    printf("%c\n", 'A');
    printf("%c\n", 65);

    printf("x�� %d �Դϴ�.\n\a", x);
	return 0;
}
